package abstractas;

import java.time.LocalDate;
import java.time.Period;

public abstract class Empleado extends Persona {
    private int legajo;
    private LocalDate fechaContratacion;
    private double salarioBase;
    private boolean activo;

    public Empleado(int id, String nombre, String apellido, LocalDate fechaNacimiento, String email,
                    int legajo, LocalDate fechaContratacion, double salarioBase) {
        super(id, nombre, apellido, fechaNacimiento, email);
        this.legajo = legajo;
        this.fechaContratacion = fechaContratacion;
        setSalarioBase(salarioBase);
        this.activo = true;
    }

    public int antiguedad() {
        return Period.between(fechaContratacion, LocalDate.now()).getYears();
    }

    public abstract double calcularSalario();

    // Getters y Setters
    public int getLegajo() { return legajo; }
    public LocalDate getFechaContratacion() { return fechaContratacion; }
    public double getSalarioBase() { return salarioBase; }
    public boolean isActivo() { return activo; }

    public void setSalarioBase(double salarioBase) {
        if (salarioBase <= 0) throw new IllegalArgumentException("El salario debe ser positivo");
        this.salarioBase = salarioBase;
    }

    public void setActivo(boolean activo) {
        this.activo = activo;
    }
}