package Personas;

import abstractas.Empleado;
import Hospital.CitaMedica;
import Hospital.Especialidad;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class Medico extends Empleado {
    private String numeroLicencia;
    private Especialidad especialidad;
    private List<Paciente> pacientesAsignados;
    private List<CitaMedica> citasAtendidas;

    public Medico(int id, String nombre, String apellido, LocalDate fechaNacimiento, String email,
                  int legajo, LocalDate fechaContratacion, double salarioBase, String numeroLicencia,
                  Especialidad especialidad) {
        super(id, nombre, apellido, fechaNacimiento, email, legajo, fechaContratacion, salarioBase);
        this.numeroLicencia = numeroLicencia;
        this.especialidad = especialidad;
        this.pacientesAsignados = new ArrayList<>();
        this.citasAtendidas = new ArrayList<>();
    }

    public void atenderPaciente(Paciente paciente) {
        pacientesAsignados.add(paciente);
    }

    @Override
    public double calcularSalario() {
        return getSalarioBase() + (especialidad != null ? especialidad.getCostoConsulta() * 0.5 : 0);
    }

    @Override
    public String obtenerTipo() {
        return "Médico";
    }

    // Getters
    public String getNumeroLicencia() { return numeroLicencia; }
    public Especialidad getEspecialidad() { return especialidad; }
}
