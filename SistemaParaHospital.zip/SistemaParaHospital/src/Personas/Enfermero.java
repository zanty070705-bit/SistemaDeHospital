package Personas;

import abstractas.Empleado;
import enums.Turno;

import java.time.LocalDate;

public class Enfermero extends Empleado {
    private Turno turno;
    private String areaAsignada;

    public Enfermero(int id, String nombre, String apellido, LocalDate fechaNacimiento, String email,
                     int legajo, LocalDate fechaContratacion, double salarioBase, Turno turno,
                     String areaAsignada) {
        super(id, nombre, apellido, fechaNacimiento, email, legajo, fechaContratacion, salarioBase);
        this.turno = turno;
        this.areaAsignada = areaAsignada;
    }

    public void asistirCirugia() {
        // lógica de asistencia
    }

    @Override
    public double calcularSalario() {
        double bonoTurno = (turno == Turno.NOCHE) ? 300 : 100;
        return getSalarioBase() + bonoTurno;
    }

    @Override
    public String obtenerTipo() {
        return "Enfermero";
    }
}