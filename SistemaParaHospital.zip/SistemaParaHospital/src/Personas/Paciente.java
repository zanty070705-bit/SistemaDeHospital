package Personas;

import abstractas.Persona;
import Hospital.CitaMedica;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class Paciente extends Persona {
    private String historiaClinicaId;
    private String grupoSanguineo;
    private List<String> alergias;
    private List<CitaMedica> citas;

    public Paciente(int id, String nombre, String apellido, LocalDate fechaNacimiento, String email,
                    String historiaClinicaId, String grupoSanguineo) {
        super(id, nombre, apellido, fechaNacimiento, email);
        this.historiaClinicaId = historiaClinicaId;
        this.grupoSanguineo = grupoSanguineo;
        this.alergias = new ArrayList<>();
        this.citas = new ArrayList<>();
    }

    public void agregarAlergia(String alergia) {
        if (alergia != null && !alergia.isBlank()) alergias.add(alergia);
    }

    public List<CitaMedica> obtenerHistorial() {
        return new ArrayList<>(citas);
    }

    public void agregarCita(CitaMedica cita) {
        citas.add(cita);
    }

    @Override
    public String obtenerTipo() {
        return "Paciente";
    }

    // Getters
    public String getHistoriaClinicaId() { return historiaClinicaId; }
    public String getGrupoSanguineo() { return grupoSanguineo; }
    public List<String> getAlergias() { return new ArrayList<>(alergias); }
}