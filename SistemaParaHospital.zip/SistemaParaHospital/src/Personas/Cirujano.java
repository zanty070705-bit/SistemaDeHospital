package Personas;

import Hospital.Especialidad;

import java.time.LocalDate;

public class Cirujano extends Medico {
    private int cirugiasRealizadas;
    private boolean disponibleEmergencias;

    public Cirujano(int id, String nombre, String apellido, LocalDate fechaNacimiento, String email,
                    int legajo, LocalDate fechaContratacion, double salarioBase, String numeroLicencia,
                    Especialidad especialidad, boolean disponibleEmergencias) {
        super(id, nombre, apellido, fechaNacimiento, email, legajo, fechaContratacion, salarioBase,
              numeroLicencia, especialidad);
        this.disponibleEmergencias = disponibleEmergencias;
    }

    public void realizarCirugia() {
        cirugiasRealizadas++;
    }

    public double calcularBono() {
        return cirugiasRealizadas * 200;
    }

    @Override
    public double calcularSalario() {
        return super.calcularSalario() + calcularBono();
    }

    @Override
    public String obtenerTipo() {
        return "Cirujano";
    }
}
