package Hospital;

import Personas.Paciente;
import abstractas.Empleado;

import java.util.ArrayList;
import java.util.List;

public class Hospital {
    private String nombre;
    private String direccion;
    private List<Empleado> empleados;
    private List<Paciente> pacientes;
    private List<CitaMedica> citas;

    public Hospital(String nombre, String direccion) {
        this.nombre = nombre;
        this.direccion = direccion;
        this.empleados = new ArrayList<>();
        this.pacientes = new ArrayList<>();
        this.citas = new ArrayList<>();
    }

    public void contratarEmpleado(Empleado empleado) {
        empleados.add(empleado);
    }

    public void registrarPaciente(Paciente paciente) {
        pacientes.add(paciente);
    }

    public void agendarCita(CitaMedica cita) {
        citas.add(cita);
        cita.getPaciente().agregarCita(cita);
    }

    public double calcularNominaTotal() {
        double total = 0;
        for (Empleado e : empleados) {
            total += e.calcularSalario();
        }
        return total;
    }

    // Getters defensivos
    public List<Empleado> getEmpleados() { return new ArrayList<>(empleados); }
    public List<Paciente> getPacientes() { return new ArrayList<>(pacientes); }
    public List<CitaMedica> getCitas() { return new ArrayList<>(citas); }
}