package Hospital;

import enums.EstadoCita;
import Personas.Paciente;
import Personas.Medico;

import java.time.LocalDateTime;

public class CitaMedica {
    private int id;
    private Paciente paciente;
    private Medico medico;
    private LocalDateTime fechaHora;
    private String motivo;
    private EstadoCita estado;
    private double costo;
    private Diagnostico diagnostico;

    public CitaMedica(int id, Paciente paciente, Medico medico, LocalDateTime fechaHora, String motivo) {
        this.id = id;
        this.paciente = paciente;
        this.medico = medico;
        this.fechaHora = fechaHora;
        this.motivo = motivo;
        this.estado = EstadoCita.PENDIENTE;
        this.costo = calcularCosto();
    }

    public double calcularCosto() {
        return medico.getEspecialidad() != null ? medico.getEspecialidad().getCostoConsulta() : 0;
    }

    public void completar(Diagnostico diagnostico) {
        this.diagnostico = diagnostico;
        this.estado = EstadoCita.COMPLETADA;
    }

    public void cancelar() {
        this.estado = EstadoCita.CANCELADA;
    }

    // Getters
    public int getId() { return id; }
    public Paciente getPaciente() { return paciente; }
    public Medico getMedico() { return medico; }
    public LocalDateTime getFechaHora() { return fechaHora; }
    public String getMotivo() { return motivo; }
    public EstadoCita getEstado() { return estado; }
    public double getCosto() { return costo; }
    public Diagnostico getDiagnostico() { return diagnostico; }
}