package Hospital;

import java.time.LocalDate;
import Personas.Medico;

public class Diagnostico {
    private int id;
    private String descripcion;
    private String receta;
    private LocalDate fecha;
    private Medico medico;

    public Diagnostico(int id, String descripcion, String receta, LocalDate fecha, Medico medico) {
        this.id = id;
        this.descripcion = descripcion;
        this.receta = receta;
        this.fecha = fecha;
        this.medico = medico;
    }

    public int getId() { return id; }
    public String getDescripcion() { return descripcion; }
    public String getReceta() { return receta; }
    public LocalDate getFecha() { return fecha; }
    public Medico getMedico() { return medico; }
}