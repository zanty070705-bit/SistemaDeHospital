package enums;

public enum EstadoCita {
    PENDIENTE, CONFIRMADA, EN_ATENCION, COMPLETADA, CANCELADA
}
