package principal;

import Hospital.Hospital;
import Hospital.Especialidad;
import Personas.Medico;
import Personas.Cirujano;
import Personas.Enfermero;
import Personas.Paciente;
import enums.Turno;
import java.time.LocalDate;
import java.time.LocalDateTime;
import Hospital.CitaMedica;
import Hospital.Diagnostico;
import abstractas.Empleado;




public class SistemaParaHospital {
    public static void main(String[] args) {
        Hospital hospital = new Hospital("Hospital Central", "Cartagena");

        Especialidad cardiologia = new Especialidad("CAR01", "Cardiología", "Atención del corazón", 500);

        Medico medico = new Medico(1, "Ana", "Gómez", LocalDate.of(1980, 5, 10), "ana@hospital.com",
                101, LocalDate.of(2010, 1, 1), 2000, "LIC123", cardiologia);

        Cirujano cirujano = new Cirujano(2, "Luis", "Martínez", LocalDate.of(1975, 3, 20), "luis@hospital.com",
                102, LocalDate.of(2005, 2, 15), 2500, "LIC456", cardiologia, true);

        Enfermero enfermero = new Enfermero(3, "María", "Pérez", LocalDate.of(1990, 7, 12), "maria@hospital.com",
                103, LocalDate.of(2018, 6, 1), 1200, Turno.NOCHE, "Urgencias");

        hospital.contratarEmpleado(medico);
        hospital.contratarEmpleado(cirujano);
        hospital.contratarEmpleado(enfermero);

        Paciente paciente = new Paciente(10, "Carlos", "Ruiz", LocalDate.of(1995, 8, 25), "carlos@gmail.com",
                "HC123", "O+");
        paciente.agregarAlergia("Penicilina");
        hospital.registrarPaciente(paciente);

        CitaMedica cita = new CitaMedica(1001, paciente, medico,
                LocalDateTime.of(2026, 3, 25, 10, 0), "Chequeo general");
        hospital.agendarCita(cita);

        Diagnostico diag = new Diagnostico(2001, "Hipertensión leve", "Medicamento X", LocalDate.now(), medico);
        cita.completar(diag);

        System.out.println("Historial del paciente:");
        for (CitaMedica c : paciente.obtenerHistorial()) {
            System.out.println("Cita con " + c.getMedico().getNombre() + " - Estado: " + c.getEstado());
        }

        System.out.println("\nCálculo de salarios:");
        for (Empleado e : hospital.getEmpleados()) {
            System.out.println(e.obtenerTipo() + " " + e.getNombre() + " → $" + e.calcularSalario());
        }

        System.out.println("\nNómina total del hospital: $" + hospital.calcularNominaTotal());
    }
}